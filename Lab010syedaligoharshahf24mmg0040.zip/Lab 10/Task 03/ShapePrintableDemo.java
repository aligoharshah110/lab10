abstract class Shape {
    abstract double area();
}

interface Printable {
    void print();
}

class Rectangle extends Shape implements Printable {
    private double width;
    private double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    double area() {
        return width * height;
    }

    @Override
    public void print() {
        System.out.println("This is a rectangle.");
    }
}

public class ShapePrintableDemo {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(5, 3);
        System.out.println("Area: " + rect.area());
        rect.print();
    }
}

