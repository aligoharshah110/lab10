abstract class Employee {
    String name;
    int id;

    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public abstract double calculateSalary();
}

interface TaxPayer {
    void payTax();
}

class FullTimeEmployee extends Employee implements TaxPayer {
    double monthlySalary;

    public FullTimeEmployee(String name, int id, double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }

    @Override
    public double calculateSalary() {
        return monthlySalary;
    }

    @Override
    public void payTax() {
        double tax = calculateSalary() * 0.2;
        System.out.println(name + " pays tax: $" + tax);
    }
}

class PartTimeEmployee extends Employee implements TaxPayer {
    double hourlyRate;
    int hoursWorked;

    public PartTimeEmployee(String name, int id, double hourlyRate, int hoursWorked) {
        super(name, id);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double calculateSalary() {
        return hourlyRate * hoursWorked;
    }

    @Override
    public void payTax() {
        double tax = calculateSalary() * 0.15;
        System.out.println(name + " pays tax: $" + tax);
    }
}

public class EmployeeTaxSystem {
    public static void main(String[] args) {
        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("Alice", 101, 5000);
        PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Bob", 102, 20, 80);

        System.out.println(fullTimeEmployee.name + "'s monthly salary: $" + fullTimeEmployee.calculateSalary());
        System.out.println(partTimeEmployee.name + "'s monthly salary: $" + partTimeEmployee.calculateSalary());

        fullTimeEmployee.payTax();
        partTimeEmployee.payTax();
    }
}
